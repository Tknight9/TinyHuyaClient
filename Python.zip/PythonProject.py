# -*- coding: gbk -*-
# coding=gbk

import tkinter
import numpy as np
from tkinter import *
from tkinter import ttk
from matplotlib import colors
from pylab import *
import io
import os
import time
import urllib
import sqlite3
import operator
import requests
import threading
import webbrowser
from PIL import Image, ImageTk
from lxml import etree
from requests.models import Response

sqlCreate1 = '''
CREATE TABLE game1heatrankinglist(
  StreamerName varchar(32) NOT NULL PRIMARY KEY,
  Heat varchar(16),
  RoomNumber varchar(16) NOT NULL
);'''

sqlCreate2 = '''
CREATE TABLE game1nickbelonggames(
  StreamerName varchar(32) NOT NULL PRIMARY KEY,
  Uid varchar(16)
);'''

sqlCreate3 = '''
CREATE TABLE game2heatrankinglist(
  StreamerName varchar(32) NOT NULL PRIMARY KEY,
  Heat varchar(16),
  RoomNumber varchar(16) NOT NULL
);'''

sqlCreate4 = '''
CREATE TABLE game2nickbelonggames(
  StreamerName varchar(32) NOT NULL PRIMARY KEY,
  Uid varchar(16)
);'''

sqlCreate5 = '''
CREATE TABLE game3heatrankinglist(
  StreamerName varchar(32) NOT NULL PRIMARY KEY,
  Heat varchar(16),
  RoomNumber varchar(16) NOT NULL
) ;'''

sqlCreate6 = '''
CREATE TABLE game3nickbelonggames(
  StreamerName varchar(32) NOT NULL PRIMARY KEY,
  Uid varchar(16)
);'''

sqlCreate7 = '''
CREATE TABLE nickinfodetail(
  StreamerName varchar(32) NOT NULL PRIMARY KEY,
  Uid varchar(16),
  Heat int,
  RoomName varchar(32),
  RoomNumber varchar(16) NOT NULL,
  GameName varchar(16) NOT NULL,
  Introduction varchar(128),
  ProfileRoom varchar(16)
);'''

def get_page(url):
	headers = {
		'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.67 Safari/537.36'}
	response = requests.get(url, headers=headers)
	return response.text

def getAllInfo(url):
	list_temp = []
	r = requests.get(url).json()
	for j in r['data']['datas']:
		data = {
			# nick��������			totalCount������			screenshot��ֱ�������
			# roomName��������		uid����������id			privateHost:˽�з����
			# gameFullName����Ϸ��	gameHostName����Ϸ���	introduction���������
			# profileName�����Է����	subscribeCount��������
			'nick': j['nick'],
			'totalCount': float("%.2f" % (float(j['totalCount']) / 10000)),
			'screenshot': j['screenshot'],
			'roomName': j['roomName'],
			'uid': j['uid'],
			'privateHost': j['privateHost'],
			'gameFullName': j['gameFullName'],
			'gameHostName': j['gameHostName'],
			'introduction': j['introduction'],
			'profileRoom': j['profileRoom'],
			'subscribeCount': 0
		}
		list_temp.append(data)
	#list_temp = sorted(list_temp, key=operator.itemgetter('totalCount'), reverse=True)
	return list_temp

# �����ݽ���ͳ�Ʒ������а�ǰʮ������
def getRankList(url):
	n = []
	list_temp = getAllInfo(url)
	list_temp = sorted(list_temp, key=operator.itemgetter('totalCount'), reverse=True)
	# ֻ�������ʮ����¼
	for k in range(0, 10):
		n.append(list_temp[k])
	return n


# ʹ������ͼ��������Ϸ�����а�ǰʮ������ʾ
def rankTop10():
	# window.state('iconic')
	colorList = ['red', 'green', 'deepskyblue', 'orange', 'gray']
	fig = plt.figure(figsize=(8, 5))
	fig.canvas.set_window_title('Popularity Ranking Top 10')

	# Ӣ������
	def game1Draw():
		# root.destroy()
		plt.clf()
		m = []
		n = []
		game1List.sort(key=operator.itemgetter('totalCount'), reverse=True)
		for i in range(0, 10):
			m.append(game1List[i]['nick'])
			n.append(game1List[i]['totalCount'])
		patches = plt.bar(x=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], height=n, width=0.25, color=colorList, tick_label=m)
		plt.legend(loc='best')
		plt.xticks(rotation=315)
		plt.title('Ӣ����������Top10')
		plt.ylabel('����/��')
		plt.xlabel('����')
		mpl.rcParams['font.sans-serif'] = ['Microsoft Yahei']

		for rect in patches:
			height = rect.get_height()
			if height != 0:
				plt.text(rect.get_x(), height + 5, '{}'.format(height))
		plt.show()

	# ��Խ����
	def game2Draw():
		# root.destroy()
		plt.clf()
		m = []
		n = []
		game2List.sort(key=operator.itemgetter('totalCount'), reverse=True)
		for i in range(0, 10):
			m.append(game2List[i]['nick'])
			n.append(game2List[i]['totalCount'])
		mpl.rcParams['font.sans-serif'] = ['Microsoft Yahei']
		patches = plt.bar(x=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], height=n, width=0.25, color=colorList, tick_label=m)
		plt.legend(loc='best')
		plt.xticks(rotation=315)
		plt.ylabel('����/��')
		plt.xlabel('����')
		plt.title('��Խ��������Top10')
		for rect in patches:
			height = rect.get_height()
			if height != 0:
				plt.text(rect.get_x(), height + 5, '{}'.format(height))
		plt.show()

	# �ƶ�֮��
	def game3Draw():
		# root.destroy()
		plt.clf()
		m = []
		n = []
		game3List.sort(key=operator.itemgetter('totalCount'), reverse=True)
		for i in range(0, 10):
			m.append(game3List[i]['nick'])
			n.append(game3List[i]['totalCount'])
		patches = plt.bar(x=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], height=n, width=0.25, color=colorList, tick_label=m)
		plt.legend(loc='best')
		plt.title('�ƶ�֮������Top10')
		plt.xticks(rotation=315)
		plt.ylabel('����/��')
		plt.xlabel('����')
		mpl.rcParams['font.sans-serif'] = ['Microsoft Yahei']

		for rect in patches:
			height = rect.get_height()
			if height != 0:
				plt.text(rect.get_x(), height + 5, '{}'.format(height))
		plt.show()

	gameName = kindbarVal.get()
	if gameName == games[0]:
		game1Draw()
	elif gameName == games[1]:
		game2Draw()
	elif gameName == games[2]:
		game3Draw()


# ʹ������ͼ�����������жԱ�
def comparing():
	# window.state('iconic')
	mpl.rcParams['font.sans-serif'] = ['Microsoft Yahei']
	fig = plt.figure(figsize=(9, 6), dpi=100, facecolor='white', edgecolor='orange', frameon=True)
	fig.canvas.set_window_title('Comparison Between Different Game')

	m, n, k = 0, 0, 0
	for i in game1List:
		m = m + i['totalCount']
	for i in game2List:
		n = n + i['totalCount']
	for i in game3List:
		k = k + i['totalCount']
	labels = ['Ӣ������', '��Խ����', '�ƶ�֮��']
	sizes = [m, n, k]
	colors = ['deepskyblue', 'yellowgreen', 'gray']
	explode = (0.05, 0.05, 0)

	patches, l_text, p_text = plt.pie(sizes, explode=explode, labels=labels, colors=colors, labeldistance=1.1,
									  autopct='%3.1f%%', radius=0.5, startangle=90, pctdistance=0.6, shadow=True)
	for t in l_text:
		t.set_size = (30)
	for t in p_text:
		t.set_size = (20)
	plt.axis('equal')
	plt.legend()
	plt.show()


def rangeCount():
	# window.state('iconic')
	def count(listi):
		res = [0 for i in range(0, 12)]
		for i in listi:
			if i['totalCount'] < 100:
				res[int(i['totalCount'] / 10)] += 1
			elif i['totalCount'] < 200:
				res[10] += 1
			else:
				res[11] += 1
		return res

	# ʹ������ͼ��Ӣ�����˺ʹ�Խ���ߵĹۿ������ķ�Χ��������ͳ��
	def drawBar():
		plt.figure().canvas.set_window_title('Game Heat Statistics')
		tLabel = ['0-10', '10-20', '20-30', '30-40', '40-50', '50-60', '60-70', '70-80', '80-90', '90-100', '100-200',
				  '>200']
		x = np.arange(1, 13)
		mpl.rcParams['font.sans-serif'] = ['Microsoft Yahei']
		patches1 = plt.bar(x - 0.3, height=count(game1List), width=0.3, color='lightskyblue',
						   tick_label=tLabel, label='Ӣ������')
		patches2 = plt.bar(x + 0.0, height=count(game2List), width=0.3, color='orange', label='��Խ����')
		patches3 = plt.bar(x + 0.3, height=count(game3List), width=0.3, color='red', label='�ƶ�֮��')

		plt.xticks(rotation=315)
		plt.legend(loc='best')
		plt.ylabel('����/��')
		plt.title('��������ͳ��ͼ(��λ��������)')
		plt.show()

	drawBar()

def logoSingleClick(self):
	webbrowser.open('https:\\www.huya.com', new=1, autoraise=True)

def treeSingleClick(self):
	def getLocalPic():
		if os.path.exists(picName):
			return picName
		else:
			return ''

	try:
		# �����¼�������LabelͼƬ
		nickUid = tree.item(tree.selection(), 'values')[3]
		gameiList = gamesDict[slbarVal.get()]
	except IndexError:
		pass
		#print('Nothing been selected, or index out of range')
	else:
		resItem = gameiList[0]
		for item in gameiList:
			if nickUid == item['uid']:
				resItem = item
				break

		picName = savePath + resItem['uid'] + '.png'
		picLocalPath = getLocalPic()
		#������ش��и�ͼƬ����ֱ�ӵ��ã�����������л�ȡͼƬ����ʾ���ٴ��뱾��
		if picLocalPath:
			img = Image.open(picLocalPath)
			img = img.resize((int(window_size_width / 2), int(window_size_height / 2)), Image.ANTIALIAS)
		else:
			img = Image.open(io.BytesIO(requests.get(resItem['screenshot']).content))
			img = img.resize((int(window_size_width / 2), int(window_size_height / 2)), Image.ANTIALIAS)
			img.save(picName)

		photo = ImageTk.PhotoImage(img)
		label_mainview.configure(image=photo)
		label_mainview.image = photo


def treeDoubleClick(self):
	# ˫���¼�����ֱ����
	try:
		url1 = 'https://www.huya.com/' + tree.item(tree.selection(), 'values')[4]
		url2 = etree.HTML(get_page(url1)).xpath(getEffectivePath)
		url = url1
		if url2:
			url = url2[0]

		webbrowser.open(url, new=1, autoraise=True)
	except BaseException:
		pass


def focusOnSearchBar(self):
	searchBar.focus()


def searchList(self):
	inval = searchBar.get()
	childList = tree.get_children()
	curItem = childList[0]

	tree.selection_set()
	for item in childList:
		for ele in tree.item(item, 'values'):
			if str(ele).find(inval) >= 0:
				tree.selection_add(item)
				break


def clearTreeview(thisTree):
	x = thisTree.get_children()
	for item in x:
		tree.delete(item)

def listUpdate(self, *args):
	# �����б�����ȡ��ǰ�б��ĳ�Ա�����ݲ˵����е��ַ����Ա��ֵ�õ���Ӧ��Ϸ�������б�
	# ����б����������б��е������������
	if args:
		gameiList = gamesDict[games[args[0]]]
	else:
		gameiList = gamesDict[slbarVal.get()]
	clearTreeview(tree)

	for i in gameiList:
		newItem = [i['nick'], i['totalCount'], i['roomName'], i['uid'], i['privateHost']]
		tree.insert('', END, value=newItem)

def initList():
	for i in game1List:
		newItem = [i['nick'], i['totalCount'], i['roomName'], i['uid'], i['privateHost']]
		tree.insert('', END, value=newItem)


def operation(theUrl, gameiList):
	temp = getAllInfo(theUrl)
	for i in temp:
		gameiList.append(i)

def getSubscribeCount(gameiList):
	count = 0
	for i in gameiList:
		url = 'https://www.huya.com//' + i['profileRoom']
		tree = etree.HTML(get_page(url)).xpath(getsubscribeCountPath)
		if tree:
			i['subscribeCount'] = int(tree[0])
		count += 1

		print(i['nick'], i['subscribeCount'], sep = '\t')

		if count >= 10:
			return
		
def insert_to_sql(cursor, tableName, infoList):
	try:
		sql = ''
		if tableName == tableList[0] or tableName == tableList[1] or tableName == tableList[2]:
			sql = "insert into %s(StreamerName, Heat, RoomNumber) values('%s', '%s', '%s');" % (tableName, infoList[0], infoList[1], infoList[2])
		elif tableName == tableList[3]:
			sql = "insert into %s(StreamerName, Uid, Heat, RoomName, RoomNumber, GameName, Introduction, ProfileRoom) values('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s');" % (
			tableName, infoList[0], infoList[1], infoList[2], infoList[3], infoList[4], infoList[5], infoList[6],
			infoList[7])
		elif tableName == tableList[4] or tableName == tableList[5] or tableName == tableList[6]:
			sql = "insert into %s(StreamerName, Uid) values('%s', '%s');" % (tableName, infoList[0], infoList[1])
			
		cursor.execute(sql)
	except BaseException:
		print('Database Connection Error.')
		
def sqlOperation():
	try:
		conn = sqlite3.connect(sqlPath)
		curs = conn.cursor()

		conn.execute(sqlCreate1)
		conn.commit()
		conn.execute(sqlCreate2)
		conn.commit()
		conn.execute(sqlCreate3)
		conn.commit()
		conn.execute(sqlCreate4)
		conn.commit()
		conn.execute(sqlCreate5)
		conn.commit()
		conn.execute(sqlCreate6)
		conn.commit()
		conn.execute(sqlCreate7)
		conn.commit()

		for i in range(100):
			insert_to_sql(curs, tableList[0], [game1List[i]['nick'], game1List[i]['totalCount'], game1List[i]['privateHost']])
			insert_to_sql(curs, tableList[1], [game2List[i]['nick'], game2List[i]['totalCount'], game2List[i]['privateHost']])
			insert_to_sql(curs, tableList[2], [game3List[i]['nick'], game3List[i]['totalCount'], game3List[i]['privateHost']])

		for i in game1List:
			insert_to_sql(curs, tableList[3], [i['nick'], i['uid'], i['totalCount'], i['roomName'], i['privateHost'], i['gameFullName'], i['introduction'], i['profileRoom']])
			insert_to_sql(curs, tableList[4], [i['nick'], i['uid']])
		for i in game2List:
			insert_to_sql(curs, tableList[3], [i['nick'], i['uid'], i['totalCount'], i['roomName'], i['privateHost'], i['gameFullName'], i['introduction'], i['profileRoom']])
			insert_to_sql(curs, tableList[5], [i['nick'], i['uid']])
		for i in game3List:
			insert_to_sql(curs, tableList[3], [i['nick'], i['uid'], i['totalCount'], i['roomName'], i['privateHost'], i['gameFullName'], i['introduction'], i['profileRoom']])
			insert_to_sql(curs, tableList[6], [i['nick'], i['uid']])

	except BaseException:
		print('Database Connection Error in main function.')
	else:
		conn.commit()
		conn.close()

def printAllTable(printLength):
	try:
		conn = sqlite3.connect(sqlPath)
		curs = conn.cursor()

		for cnt in range(7):
			count = 0
			res = curs.execute('select * from %s;' % (tableList[cnt]))
			print(tableList[cnt] + ':')
			for i in res:
				print(i)
				count += 1
				if count >= printLength:
					break

			print('\n\n')
	except BaseException:
		print('Print Table Failed...')
	else:
		conn.close()

#Treeview�����������з�ʽ
def treeview_sort_column(tv, col, reverse, dataType):
	l = [(tv.set(k, col), k) for k in tv.get_children('')]
	if dataType == 'float':
		l.sort(key=lambda t: float(t[0]), reverse=reverse)
	elif dataType == 'str':
		l.sort(key=lambda t: str(t[0]), reverse=reverse)

	for index, (val, k) in enumerate(l):
		tv.move(k, '', index)
	tv.heading(col, command=lambda: treeview_sort_column(tv, col, not reverse, dataType))

def updateGameList():
	# ���̻߳�ȡÿ����Ϸ�������б���ÿ����Ϸÿһҳ120����¼��2-5��3ҳ��3����Ϸ��3*3*120����¼����ȡ
	for i in range(1, 1 + totalPages):
		threading.Thread(target=operation, args=(game1Url + str(i), game1List)).start()
		threading.Thread(target=operation, args=(game2Url + str(i), game2List)).start()
		threading.Thread(target=operation, args=(game3Url + str(i), game3List)).start()

def refreshTree(self):
	game1List.clear()
	game2List.clear()
	game3List.clear()
	updateGameList()
	time.sleep(1.5)
	listUpdate(0, 0)
	listUpdate(0, 1)
	listUpdate(0, 2)
	treeview_sort_column(tree, "totalCount", True, 'float')

# �������ef632b		����93b5cf		���ݳ�f0945d		��ˮ��baccd9
# ����5698c3			����1e9eb3		�ٲ���51c4d3		������55bb8a
# defaultColor��Ĭ�ϱ���ɫ	kindbarColor���˵����ı���ɫ	searchBarColor�������򱳾�ɫ
defaultColor = '#55bb8a'
kindbarColor = '#baccd9'
searchBarColor = 'white'

# savePath��ֱ������汣��·��		iconPath��������ͼ��·��		logoPath��logo��·��
# labelImgPath����ֱ����ѡ��ʱĬ����ʾ��ͼƬ·��
savePath = 'B:\StudyData\Python\Python\Img\\'
sqlPath = 'B:\StudyData\Python\Python\huya.db'
iconPath = 'B:\StudyData\Python\Python\screenDuck.ico'
logoPath = 'B:\StudyData\Python\Python\logo.png'
labelImgPath = 'B:\StudyData\Python\Python\WhiteBear_1.png'

# hostName�����ݿ�������ַ		userName�����ݿ��¼��		psWd����½����		dbName�����ݿ����
#hostName, userName, psWd, dbName = 'localhost', '', '', ''
tableList = ['game1heatrankinglist', 'game2heatrankinglist', 'game3heatrankinglist', 'nickinfodetail',
			'game1nickbelonggames', 'game2nickbelonggames', 'game3nickbelonggames']

window = Tk()
window_size_width = 1440
window_size_height = 810
window_pos_width = int((window.winfo_screenwidth() - window_size_width) / 2)
window_pos_height = int((window.winfo_screenheight() - window_size_height) / 2)
button_width = window_size_width / 10
button_height = window_size_height / 20
getEffectivePath = '/html/body/div[2]/div/p/a/@href'
getsubscribeCountPath = '//*[@id="activityCount"]/text()'
game1Url = 'https://www.huya.com/cache.php?m=LiveList&do=getLiveListByPage&gameId=1&tagAll=0&page='
game2Url = 'https://www.huya.com/cache.php?m=LiveList&do=getLiveListByPage&gameId=4&tagAll=0&page='
game3Url = 'https://www.huya.com/cache.php?m=LiveList&do=getLiveListByPage&gameId=5485&tagAll=0&page='
game1List = []
game2List = []
game3List = []
games = ['Ӣ������', '��Խ����', '�ƶ�֮��']
gamesDict = {games[0]: game1List, games[1]: game2List, games[2]: game3List}
totalPages = 3

updateGameList()
time.sleep(1.5)
# �����ڣ������˴��ڴ�С�����ڳ�ʼλ�ã����ڱ���ɫ�������Լ�ͼ��
window.geometry('{}x{}+{}+{}'.format(window_size_width, window_size_height,
									 window_pos_width, window_pos_height))
window.configure(bg=defaultColor)
window.title('Huya Gaming Rank List Viewer')
window.iconbitmap(iconPath)

# ҳ����ͼ��(����logo)
logoImg = Image.open(logoPath)
logoPhoto = ImageTk.PhotoImage(logoImg)
label_logoview = Label(window, image=logoPhoto, height=window_size_height / 4,
					   width=550, bg=defaultColor, cursor='hand2')
label_logoview.bind('<ButtonRelease-1>', logoSingleClick)
label_logoview.place(x=10, y=10)

# �������ݱȽϹ���
r1 = Radiobutton(window, text='������Χͳ��ͼ', font=('Consolas', 18), fg='red',
				 indicatoron=False, command=rangeCount, width=15, height=1)
r2 = Radiobutton(window, text='�����Ա�ͼ', font=('Consolas', 18), fg='red',
				 indicatoron=False, command=comparing, width=15, height=1)
r3 = Radiobutton(window, text='����Top10��', font=('Consolas', 18), fg='red',
				 indicatoron=False, command=rankTop10, width=15, height=1)
r1.place(x=10, y=10 + int(button_height * 5.5))
r2.place(x=10, y=10 + int(button_height * 7))
r3.place(x=360, y=10 + int(button_height * 7))

# �˵������ڲ˵�����ѡ�����Ϸ����ı���'����Top10��'�Ļ�ͼ���
kindbarVal = StringVar(value=games[0])
kindbar = OptionMenu(window, kindbarVal, *games)
kindbar.config(bg=kindbarColor)
kindbar.place(x=360, y=10 + int(button_height * 5.5), width=205, height=40)

# label��ǩ��ͼƬ��ʾ
img = Image.open(labelImgPath)
photo = ImageTk.PhotoImage(img)
label_mainview = Label(window, image=photo, cursor='hand2', bg=defaultColor,
					   width=window_size_width / 2, height=window_size_height / 2,)
label_mainview.bind('<ButtonRelease-1>', treeDoubleClick)
label_mainview.place(x=window_size_width / 2 - 100, y=10)

# �˵������ڲ˵�����ѡ����Ϸ���б���ȡ��Ӧ��Ϸ�������б�
slbarVal = StringVar(value=games[0])
slbar = OptionMenu(window, slbarVal, *games, command=listUpdate)
slbar.config(bg=defaultColor)
slbar.place(x=10, y=10 + window_size_height / 2 - button_height, width=200, height=button_height)

# ˢ���б�
refreshButton = Radiobutton(window, bg = 'white', fg = 'black', font=('Consolas', 18),
							height=1, width=5, text='ˢ��', relief=SUNKEN,
							command=lambda:refreshTree(0), indicatoron=False)
refreshButton.bind_all('<F5>', refreshTree)
refreshButton.place(x=250, y=10 + window_size_height / 2 - button_height)

# ������
searchBar = Entry(window, bg=searchBarColor)
searchBar.bind('<Return>', searchList)
searchBar.bind_all('<Control-f>', focusOnSearchBar)
searchBar.place(x=360, y=10 + window_size_height / 2 - button_height, width=200,
				height=button_height)
style = ttk.Style(window)
# set ttk theme to "clam" which support the fieldbackground option
style.theme_use("clam")
style.configure("Treeview", background=defaultColor,
				fieldbackground=defaultColor, foreground="black")

# �����б����������������б��⣬���������������ͷ��¼�
treeview_width = window_size_width - 40
treeview_height = window_size_height / 2 - 30
tree = ttk.Treeview(window, height=10, show='headings', selectmode='browse', takefocus=True,
					columns=("nick", "totalCount", "roomName", "uid", "privateHost"))
tree.column("nick", width=int(treeview_width * 0.2))
tree.column("totalCount", width=int(treeview_width * 0.1))
tree.column("roomName", width=int(treeview_width * 0.4))
tree.column("uid", width=int(treeview_width * 0.1))
tree.column("privateHost", width=int(treeview_width * 0.1))
tree.heading("nick", text="����", command=lambda c="nick":treeview_sort_column(tree, c, False, 'str'))
tree.heading("totalCount", text="����ֵ/��", command=lambda c="totalCount":treeview_sort_column(tree, c, False, 'float'))
tree.heading("roomName", text="����", command=lambda c="roomName":treeview_sort_column(tree, c, False, 'str'))
tree.heading("uid", text="����id", command=lambda c="uid":treeview_sort_column(tree, c, False, 'str'))
tree.heading("privateHost", text="˽�з����", command=lambda c="privateHost":treeview_sort_column(tree, c, False, 'str'))
yscroll = Scrollbar(tree, orient=VERTICAL)
yscroll['command'] = tree.yview
yscroll.pack(side=RIGHT, fill=BOTH)
tree['yscrollcommand'] = yscroll.set
tree.bind('<ButtonRelease-1>', treeSingleClick)
tree.bind('<Double-Button-1>', treeDoubleClick)
tree.place(x=10, y=20 + window_size_height / 2, width=treeview_width, height=treeview_height)

getSubscribeCount(game1List)
#getSubscribeCount(game2List)
#getSubscribeCount(game3List)
initList()
treeview_sort_column(tree, "totalCount", True, 'float')
#sqlOperation()
#printAllTable(5)

window.mainloop()
